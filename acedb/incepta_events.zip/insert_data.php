<?php
include('db_connect.php');
//error_reporting(0);

if (isset($_POST['submit_btn'])) {
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $organization = $_POST['organization'];
    $q01 = $_POST['q01'];
    $q02 = $_POST['q02'];
    $q03 = $_POST['q03'];
    $q04 = $_POST['q04'];
    $q05 = $_POST['q05'];
    echo "<br>";
    echo $name.$mobile.$organization.$q01.$q02.$q03.$q04.$q05;

    $query = "INSERT INTO `acedb_table`(`id`, `name`, `mobile`, `organization`, `q1`, `q2`, `q3`, `q4`, `q5`)
      VALUES (null,'$name','$mobile','$organization','$q01','$q02','$q03','$q04','$q05')";
    $ifInset = mysqli_query($db,$query);
    if ($ifInset) {
        echo "<br> Data Inserted Successfull";
    } else {
        echo "Not Insert".mysqli_error();
    }

}
?>